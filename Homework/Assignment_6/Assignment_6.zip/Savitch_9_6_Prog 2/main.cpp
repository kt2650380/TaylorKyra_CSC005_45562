/* 
 * File:   main.cpp
 * Author: Kyra Taylor
 * Created on July 23, 2017, 07:48 PM
 * Purpose:  Practice Program 1, Where is the 2 in an array.  
 */

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include <string>
using namespace std;
bool firstLast2(int in[], int len);

int main()
{
    int arr1[5]={2,0,4,1,5}
    ,arr2[7]={3,1,4,2,8,6,9}
    ,arr3[4]={1,3,4,5};
    
    if(firstLast2(arr1,5))
        cout<<"array 1 contains 2 in beginning or end.\n";
    else
        cout<<"array 1 does not contain 2 in either the beginning or end.\n";
    
    if(firstLast2(arr2,4))
        cout<<"array 2 with only 4 element contains 2 in beginning or end of array.\n";
    else 
        cout<<"array 2 with only 4 elements does nt contain 2 in either beginning or end.\n";
    if(firstLast2(arr2,7))
        cout<<"array 2 with all 7 elements contains 2 in beginning or end of array.\n";
    else
        cout<<"array 2 with all 7 elements does not contain 2 in either beginning or end.\n";
        
    if(firstLast2(arr3,4))
        cout<<"array 3 contains 2 in beginning or end.\n";
    else 
        cout<<"array 3 does not contain 2 in their beginning or end.\n";
}
  bool firstLast2(int in[], int len){
      if(in[0]==2 || in[len-1]==2)
          return true;
      else
          return false;
  }

 


