/* 
 * File:   main.cpp
 * Author: Kyra Taylor
 * Created on July 23, 2017, 07:48 PM
 * Purpose:  Practice Program 1, Input a file and read the largest and smallest numbers from the file. 
 */

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>
using namespace std;

int main()
{
    ifstream in_stream;
    in_stream.open("//Mac/Home/Desktop/numbers.txt");
    
    if (in_stream.fail())
    {
        cout << "Input file opening failed\n";
        exit(1);
    }
    
    int integer,
    largest,
            smallest;
    if(in_stream>>integer)
    {
    largest = integer;
    smallest = integer;
    
    while (in_stream>>integer)
    {
        if(integer > largest)
        
            largest = integer;
        if (integer < smallest)
        
            smallest = integer;
        
    }
        
    
    cout << largest<<"\n";
    cout << smallest<<"\n";
    
    }
    return 0;
}

