/* 
 * File:   main.cpp
 * Author: Kyra Taylor
 * Created on July 23, 2017, 07:48 PM
 * Purpose:  Practice Program 5, Advice by many.  
 */

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include <string>
using namespace std;

int main()
{
    ifstream in_stream;
    ofstream out_stream;
    string advice;
    in_stream.open("//Mac/Home/Desktop/Advice.txt");
    
    if (in_stream.fail())
    {
        out_stream.open("//Mac/Home/Desktop/Advice.txt");
        cout<<"Never let the fear of striking out keep you from playing the game"<<endl;
        cout<<"Enter your advice: "<<endl;
        
        do
        {getline(cin,advice);
        out_stream<<advice;
        out_stream<<endl;
        }
        while(advice!="\0");
        out_stream.close();
        exit(1);
    }
    char next;
    while(!in_stream.eof())
    {
        cout<<next;    
        in_stream.get(next);
}
    out_stream.open("//Mac/Home/Desktop/Advice.txt");
    cout<<"Enter your advice"<<endl;
    
    do
    {
        getline(cin,advice);
        out_stream<<advice;
        out_stream<<endl;
    }
    while(advice!="\0");
    in_stream.close();
    out_stream.close();
    


    
    
    
    return 0;
}

