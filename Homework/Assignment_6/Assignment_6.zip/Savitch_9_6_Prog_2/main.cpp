/* 
 * File:   main.cpp
 * Author: Kyra Taylor
 * Created on July 23, 2017, 07:48 PM
 * Purpose:  Practice Program 5, Advice by many.  
 */

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include <string>
using namespace std;

int main()
{
    ifstream in_stream;
    ofstream out_stream;
    long num, sum = 0, average;
    int count = 0;
    
    in_stream.open("//Mac/Home/Desktop/Grades.txt");
    
    if (in_stream.fail())
    {
       
        cout<<"The input file failed to open\n";
        exit(1);
    }
        
    while(!in_stream.eof())
    {
        in_stream>>num;
        sum+=num;
        count++;
    }

    average = sum/count;
    in_stream.close();
    cout<<"Average of the number in the file: "<<average;

    
    
    
    return 0;
}

