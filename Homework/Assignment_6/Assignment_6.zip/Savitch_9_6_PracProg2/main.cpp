/* 
 * File:   main.cpp
 * Author: Kyra Taylor
 * Created on July 23, 2017, 07:48 PM
 * Purpose:  Practice Program 2, Calculate the average of a list of numbers from a file.  
 */

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>
using namespace std;

int main()
{
    ifstream in_stream;
    in_stream.open("//Mac/Home/Desktop/numbers.txt");
    
    if (in_stream.fail())
    {
        cout << "Input file opening failed\n";
        exit(1);
    }
    
    float next, average, sum = 0;
    int count = 0;
   
    
    while (in_stream>>next)
    {
        
        
        sum = sum + next; 
          count++;
        
    
     cout.setf(ios::fixed);
     cout.setf(ios::showpoint);
     cout.precision(4);
    average = sum / count;
    

     
    
    }
    cout <<"The average of our number list is "<< average;
    return 0;
}

