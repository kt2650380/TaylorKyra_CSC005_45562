/* 
 * File:   main.cpp
 * Author: Kyra Taylor
 * Created on June 23, 2017, 12:20 PM
 * Purpose: Practice Program 2 Make a C and S
 */

#include <iostream>
using namespace std;



int main(int argc, char** argv)
{
    cout <<"\n ******************************************************";
    
    cout <<"\n ";
    cout <<"\n                 C C C             S S S S           !!";
    cout <<"\n               C       C         S         S         !!";
    cout <<"\n              C                 S                    !!";
    cout <<"\n             C                   S                   !!";
    cout <<"\n             C                     S S S S           !!";
    cout <<"\n             C                             S         !!";
    cout <<"\n              C                             S        !!";
    cout <<"\n               C       C         S         S         !!";
    cout <<"\n                 C C C             S S S S           !!";
    cout <<"\n ******************************************************";
    
    cout <<"\n ";
    cout <<"\n    Computer Science is Cool Stuff!!!\n";
    
    
    
    
   
    
           
            
    
    
    
    
    return 0;
}

