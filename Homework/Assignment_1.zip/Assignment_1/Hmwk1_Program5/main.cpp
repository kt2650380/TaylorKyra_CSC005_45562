/* 
 * File:   main.cpp
 * Author: Kyra Taylor
 * Created on June 23, 2017, 12:20 PM
 * Purpose: Practice Program 5 Make a C
 */

#include <iostream>
using namespace std;



int main(int argc, char** argv)
{
    char c;
    
    cout<< "What character would you like to use";
    cout<< "to make a Big Letter C";
    cin >> c;
    
    cout<<endl;
    cout<<"  "<<c<<c<<c<<endl;
    cout<<" "<<c<<"  "<<c<<endl;
    cout<<" "<<c<<endl;
    cout<<" "<<c<<endl;
    cout<<" "<<c<<endl;
    cout<<" "<<c<<"  "<<c<<endl;
    cout<<"  "<<c<<c<<c<<endl;
    
    
   
    
           
            
    
    
    
    
    return 0;
}

