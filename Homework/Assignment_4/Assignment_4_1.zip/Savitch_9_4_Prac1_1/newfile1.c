/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


#include <iostream>
using nampespace std;

int main()
{
   
    const double lit_to_gal = 0.26479;
    cout << "Enter how many liters of gas are consumed by your car\n";
    cout <<"Then press return\n";
    
    cin >> liters;
     gal_total = liters * lit_to_gal;