/* 
 * File:   main.cpp
 * Author: Kyra Taylor
 * Created on July 10, 2017, 3:45 PM
 * Purpose: Practice Program 1- Liters to Gallons Conversion
 */

# include <iostream.h>
using namespace std;

static_cast<double>(drive_too)(short liters_par, short miles_par);